Projeto de "Clonagem" do site Ifood.com.br para fins academicos. 
